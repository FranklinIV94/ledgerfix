# LedgerFix — Post-Hackathon Handoff + Improvement Plan (to Prospyr Prime standard)

**2026-09-19 · Author: Prospyr Prime (verified live, not from the agent's self-report)**

> **Verdict up front:** the ledger/report engine is **demo-clean and verified live** on
> ledgerfix.prospyr305.com (14 claims → 6 exceptions → $26,030 recoverable → CRITICAL #1 =
> the $18,400 WC-1051 duplicate). The product works. What is **not yet to our standard**:
> (1) the voice path is unverified end-to-end, (2) the demo narrative + stage polish are
> unwritten, (3) several UI/robustness gaps. This doc is the honest gap list + the exact
> fixes, in priority order.

---

## 0. Live verification (I did this now, not from the handoff)
| Check | Result |
|---|---|
| `GET /api/health` | `{"status":"ok","service":"ledgerfix"}` — 200 |
| `GET /` (UI) | HTTP 200 |
| `POST /api/reconcile` (sample) | success, 14 claims, **6 exceptions** |
| `recoverable_total` | **$26,030** — math re-verified by hand: dup $18,400 + denied $7,050 + variance $580 |
| Headline | CRITICAL #1 = WC-1051 Carmen Delgado $18,400 duplicate (WC-1051/WC-1052) |
| `next_action_queue` | action-specific (void/reissue, appeal, recovery-demand, corrected payment) — a clerk can act without the source |

**Confirmed: the "duplicate counted once" fix is correct live** — $26,030, not double-counted.

---

## 1. 🟢 What's already to standard (keep)
- **Engine deterministic** — rules, no LLM arithmetic. Every dollar traces to a ledger line. This is the integrity that wins.
- **Report artifact** carries `generated_at`, `claims_scanned`, totals, `recoverable_total`, `exception_summary`, `priorities`, `headline`, ranked `exceptions[]`, `next_action_queue[]` — auditable.
- **Deploy loop clean** — laptop push → GitHub → auto-deploy Render → custom domain, 0 deps. Proven.
- **No secrets in repo** — ElevenLabs key client-side per request, never stored. Good security posture.

---

## 2. 🔴 MUST-FIX before demo (in order)

### M1. Voice path unverified end-to-end — the Best-ElevenLabs beat is still at risk
This is the single biggest gap. `/api/narrate` was only tested for **script generation**, not
**real synthesis** — the ElevenLabs key in Mel's connector is rejected by ElevenLabs.

**Fix now:**
1. Paste a **working `sk_` ElevenLabs key** (we have one verified today — `sk_2e93…`, see §4) into the UI once, click narrate, confirm an MP3 actually returns.
2. **Use `eleven_v3` + Franklin's cloned voice `b49BEbpA9R0tq5wqd5yV`.** ⚠️ The handoff lists the fallback model as `eleven_multilingual_v2` — **that is the robotic model we already rejected this morning.** Correct the code + the doc.
3. **Pre-generate the fallback MP3.** We have it: `ledgerfix-findings-franklin.mp3` (611KB, 38.2s, cloned voice, eleven_v3). Stage it as the offline backup so a cold-start/latency/key failure can't kill the demo.
4. Confirm the clone + `eleven_v3` are actually on the account (mel's stored key may be a different account than ours).

### M2. The demo narrative is unwritten — the live 5–7 min talk track
A working product with no story loses to a mediocre one with a story. The 3-minute script exists
(`demo-script.md`) but has not been adapted to **this deployed product with the real numbers**
(it references VM paths). Re-cut it to the live flow. See §5.

### M3. Submission/demo-deadline clarity
Handoff says "confirm the exact time" — **already confirmed: 6:00 PM ET submission cutoff, 6:00–8:30 live demos + judging + awards.** Lock this in; the clock is real.

---

## 3. 🟡 Should-fix (high polish value, cheap)

### S1. Underpayment sign lost in UI (confirmed from live payload)
WC-1046 internal amount is `-280` but `public/app.js` formats `Math.abs(amount)` + only prefixes
`+` when positive → the −$280 underpayment renders as `$280` with no sign. The `.underpay` class
colors it but the direction is unclear. **Fix:** format with an explicit `−` / `+` sign from the
raw value, don't strip it. One-liner; matters because a "recoverable $26,030" that hides a
minus looks wrong to an auditor.

### S2. Free instance cold start (30–50s) — demo killer
After 15 min idle the Render free instance spins down; 30–50s wake. **Mitigation:** pre-warm the
URL ~60s before presenting, OR upgrade to Starter ($7) for demo day. A dead 30s at the start of a
5-min pitch is fatal. Pre-warm (curl the URL before you go on) is free and usually enough.

### S3. `report.headline` is a string, not an object
Live payload: `headline` = `"6 exceptions found across 14 claims — $26,030.00 recoverable."`
(not the structured `{severity,type,claim_id,amount}` the handoff implies). If any UI/code
expects the structured form it must handle the string. Not blocking, but **align the contract**
between `report.js` and whatever reads it so docs match reality.

### S4. Sequential exception rendering → tighten for the demo
Findings render as a flat list. A severity filter (or collapse the 3 MEDIUM into a "other
variations" group) would focus the 3-min demo on the CRITICAL + HIGH. Cheap and high polish.

---

## 4. 🟠 Our assets (from this morning — reuse, don't reinventory)
| Asset | Path | Use |
|---|---|---|
| **Cloned voice MP3 (your voice, eleven_v3)** | `/root/hackathon/ledgerfix-findings-franklin.mp3` | **Demo voice fallback + reference recording** |
| Working ElevenLabs key | `sk_2e93…` (verified 200 today) | Test `/api/narrate` live |
| Clone voice ID | `b49BEbpA9R0tq5wqd5yV` | Correct model/voice in `voice.js` |
| Recon engine (reference) | `/root/hackathon/recon.py` | The rules LedgerFix implements — cross-check |
| 3-min script | `/root/hackathon/demo-script.md` | Adapt to live product (§5) |
| Build brief / kickoff | `BUILD_BRIEF.md`, `MEL_KICKOFF.md` | The spec Mel/Claude built from |

---

## 5. Suggested demo narrative (adapt to the live product)
> Tie the numbers to the product, not the repo paths. ~3 min, then let voice play fully.

1. **Hook (10s):** "Claims practices reconcile by hand, every month, and they miss things. A
   line-by-line clerk misses the expensive one."
2. **Setup (20s):** "This is a real month — 14 claims, $79k. LedgerFix closes the books on it."
   → load the sample.
3. **The money beat (40s):** report populates → "6 exceptions, $26,030 recoverable. It found
   the duplicate a clerk missed — paid twice across WC-1051/WC-1052." Point at CRITICAL.
4. **The voice (30s):** hit narrate → cloned voice reads findings. **Do NOT talk over it.**
   This is the Best-ElevenLabs moment.
5. **Close (30s):** "Accounting records the past. LedgerFix owns the close — finds the error,
   tells you what to do, says it out loud. In a business where one billing error costs a
   penalty, you can't afford not to have this."

---

## 6. Open questions to close (ask Franklin / not decided)
1. Upgrade Render to Starter ($7/mo, no cold start) for demo day, or pre-warm the URL?
2. Default branch is `master` — rename to `main` before adding any links, or leave (fine for an
   in-person demo)?
3. Voice: use the cloned voice + `eleven_v3` live (needs a working key in the UI), or fall back
   to the pre-generated MP3 on stage?

---

## 7. What to do with this doc
- **Now (demo prep):** M1 (voice) → M2 (narrative) → M3 (deadline). Then S1–S4 as time allows.
- **After the event:** file the M1/S1/S2/S3 fixes as GitHub issues on `FranklinIV94/ledgerfix`,
  tagged `demo-blocker`/`polish`, so the product is presentable for real clients — not just the
  hackathon. This is genuinely sellable to the MM&R / claims world we already scope.
