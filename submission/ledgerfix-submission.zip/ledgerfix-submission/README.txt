LedgerFix - Miami AI Hackathon (Mel + ElevenLabs), Sep 19 2026
Live: https://ledgerfix.prospyr305.com
Repo: https://github.com/FranklinIV94/ledgerfix
Contents: demo-script.md (3-minute talk track), ledgerfix-findings-franklin.mp3 (cloned-voice narration of the sample findings, eleven_v3), LEDGERFIX_HANDOFF.md (verified status + gap list).
